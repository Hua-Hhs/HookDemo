*******文本格式*******
         CodeAndAddress.txt中的文本格式为一行按键一行地址，地址的分隔符要用双反斜线\\
         例如：

a
D:\\application\\1642910981999.wav


          按下小写a键，播放地址为D:\application\1642910981999.wav的音频。

*******功能按键*******
          F11退出程序
          F12关闭或开启功能，默认为开启
        （笔记本电脑记得按下fn键才能用F11和F12）

*******注意事项*******
          程序运行一个即可，运行多个可能有重音
          CodeAndAddress.txt文件要与hookDemo.exe置于同一文件夹下，可创建快捷方式，右键hookDemo.exe创建
          程序启动后第一次按键不会读取，所以第一次按下任意按键后再按F12开启功能
          文本内不能有地址末尾多余空格
          路径中只支持引文字母
          只支持单按键播放，不支持组合键（如ctrl+a）
          网易云等音乐软件下载的MP3格式不能直接使用，可在https://www.musicenc.com下载MP3格式文件，或使用格式工厂等软件将MP3格式转换为wav格式



*******部分特殊按键*******
    Tab键的文本格式为[TAB],其他按键同理
    case VK_NUMLOCK: key = "[NUM-LOCK]"; break;
    case VK_SCROLL:  key = "[SCROLL-LOCK]"; break;
    case VK_BACK:    key = "[BACK]"; break;
    case VK_TAB:     key = "[TAB]"; break;
    case VK_CLEAR:   key = "[CLEAR]"; break;
    case VK_RETURN:  key = "[ENTER]"; break;
    case VK_SHIFT:   key = "[SHIFT]"; break;
    case VK_CONTROL: key = "[CTRL]"; break;
    case VK_MENU:    key = "[ALT]"; break;
    case VK_PAUSE:   key = "[PAUSE]"; break;
    case VK_CAPITAL: key = "[CAP-LOCK]"; break;
    case VK_ESCAPE:  key = "[ESC]"; break;
    case VK_SPACE:   key = "[SPACE]"; break;
    case VK_PRIOR:   key = "[PAGEUP]"; break;
    case VK_NEXT:    key = "[PAGEDOWN]"; break;
    case VK_END:     key = "[END]"; break;
    case VK_HOME:    key = "[HOME]"; break;
    case VK_LEFT:    key = "[LEFT]"; break;
    case VK_UP:      key = "[UP]"; break;
    case VK_RIGHT:   key = "[RIGHT]"; break;
    case VK_DOWN:    key = "[DOWN]"; break;
    case VK_SELECT:  key = "[SELECT]"; break;
    case VK_PRINT:   key = "[PRINT]"; break;
    case VK_SNAPSHOT: key = "[PRTSCRN]"; break;
    case VK_INSERT:  key = "[INS]"; break;
    case VK_DELETE:  key = "[DEL]"; break;
    case VK_HELP:    key = "[HELP]"; break;